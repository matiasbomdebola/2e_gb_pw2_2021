const express = require('express')
const server = express()
const mysql = require('mysql2')
const banco = mysql.createPool({
    user: 'root',
    password: 'minas',
    database: '2e_gb_2021',
    host: 'localhost',
    port: '3306'
})
server.get('/clientes', (req, res)=>{
    const SQL = 'SELECT * FRPM clientes'
    banco.getConnection((erro, con)=>{
        if(erro){
            return res.status(500).send({
                mensagem: 'erro no servidor'
                detalhes: erro
            })
        }
        con.query(SQL, (erro, resultados)=>{
            con.release()
            if(erro){
                return res.status(500).send({
                    mensagem: 'erro ao executar a busca'
                    detalhes: erro
                })
            }
            return res.status(500).send({
                mensagem: 'clientes recuperados com sucesso'
                data: resultados
            })
        })
    })
})
server.get('/testarconexao',(req, res)=>{
    banco.getConnection((erro, con)=>{
        if(erro){
            return res.status(500).send({
                mensagem: 'erro no servidor'
                detalhes: erro
            })
        }
        con.release()
        return res.status(200).send({
            mensagem: 'conexão estabelecida com sucesso'
        })
    })
})
server.get('/', (req, res, next) => {
    return res.status(200).send({
        mensagem: 'Servidor funcionando!'
    })
})

server.listen(3000, () => {
    console.log('Em execução')
})

